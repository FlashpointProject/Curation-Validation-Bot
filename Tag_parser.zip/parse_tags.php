<?php
//Includes
chdir(dirname(__FILE__));
include "simple_html_dom.php";

//Config
$url = "https://bluemaxima.org/flashpoint/datahub/Tags";
$category_tags_file = "category_tags.json";
$tags_output_file = "tags.json";

//Initialize tags
$tags = [];

//Prefill tags array with category tags defined in $category_tags_file
if(file_exists($category_tags_file))
{
	$tags = array_fill_keys(json_decode(file_get_contents($category_tags_file), true)["tags"] ?? [], true);
}

//Load tags wiki page and find all table rows
$html = new simple_html_dom();
$html->load_file($url);
$tag_rows = $html->find("table tr");

//Iterate through all rows and add tags to tags array
foreach($tag_rows as $row)
{
	$cell = $row->find("td", 0);
	
	if(empty($cell) == false)
	{
		//Add tags by key to skip having to remove duplicates
		$tag = htmlspecialchars_decode(trim($cell->plaintext));
		$tags[$tag] = true;
	}
}

//Sort tags array using natural sort and save to file defined in $tags_output_file
uksort($tags, "strnatcasecmp");
file_put_contents($tags_output_file, json_encode(["tags" => array_keys($tags)]));

//Give some feedback to know when script is done, since there can be a long delay when loading external pages
echo "Done. Found " . count($tags) . " tags";